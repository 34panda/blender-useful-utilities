# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "blender_useful_utilities",
    "author" : "Daniil Ivzhenko", 
    "description" : "Blender Useful Utilities is an addon created to improve work ergonomics by giving useful tools and shortcuts",
    "blender" : (4, 2, 0),
    "version" : (1, 0, 0),
    "location" : "Poland",
    "warning" : "Created and tested only on Blender version 4.2.0",
    "doc_url": "https://github.com/34panda/blender-useful-utilities", 
    "tracker_url": "", 
    "category" : "Ergonomics" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


def sna_update_sna_resolution__88E21(self, context):
    sna_updated_prop = self.sna_resolution_
    if sna_updated_prop == "0.25x":
        bpy.context.scene.render.resolution_percentage = 25
    elif sna_updated_prop == "0.5x":
        bpy.context.scene.render.resolution_percentage = 50
    elif sna_updated_prop == "1x":
        bpy.context.scene.render.resolution_percentage = 100
    elif sna_updated_prop == "1.5x":
        bpy.context.scene.render.resolution_percentage = 150
    elif sna_updated_prop == "2x":
        bpy.context.scene.render.resolution_percentage = 200
    elif sna_updated_prop == "3x":
        bpy.context.scene.render.resolution_percentage = 300
    else:
        pass


def sna_update_sna_image_dimensions_B129B(self, context):
    sna_updated_prop = self.sna_image_dimensions
    if sna_updated_prop == "Default 16:9":
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
    elif sna_updated_prop == "Square 1:1":
        bpy.context.scene.render.resolution_x = 1080
        bpy.context.scene.render.resolution_y = 1080
    elif sna_updated_prop == "Filmic 21:9":
        bpy.context.scene.render.resolution_x = 2560
        bpy.context.scene.render.resolution_y = 1080
    elif sna_updated_prop == "Instagram 3:4":
        bpy.context.scene.render.resolution_x = 768
        bpy.context.scene.render.resolution_y = 1024
    elif sna_updated_prop == "Facebook 4:5":
        bpy.context.scene.render.resolution_x = 1080
        bpy.context.scene.render.resolution_y = 1350
    else:
        pass


def sna_update_sna_render_quality_9B4C8(self, context):
    sna_updated_prop = self.sna_render_quality
    if sna_updated_prop == "Mini":
        bpy.context.scene.cycles.use_adaptive_sampling = True
        bpy.context.scene.cycles.adaptive_threshold = 1.0
        bpy.context.scene.cycles.samples = 15
        bpy.context.scene.cycles.use_denoising = False
        bpy.context.scene.cycles.max_bounces = 2
        bpy.context.scene.cycles.diffuse_bounces = 2
        bpy.context.scene.cycles.glossy_bounces = 2
        bpy.context.scene.cycles.transmission_bounces = 2
        bpy.context.scene.cycles.volume_bounces = 2
        bpy.context.scene.cycles.transparent_max_bounces = 2
    elif sna_updated_prop == "Low":
        bpy.context.scene.cycles.use_adaptive_sampling = True
        bpy.context.scene.cycles.adaptive_threshold = 0.5
        bpy.context.scene.cycles.samples = 50
        bpy.context.scene.cycles.use_denoising = False
        bpy.context.scene.cycles.max_bounces = 4
        bpy.context.scene.cycles.diffuse_bounces = 2
        bpy.context.scene.cycles.glossy_bounces = 4
        bpy.context.scene.cycles.transmission_bounces = 4
        bpy.context.scene.cycles.volume_bounces = 2
        bpy.context.scene.cycles.transparent_max_bounces = 2
    elif sna_updated_prop == "Normal":
        bpy.context.scene.cycles.use_adaptive_sampling = True
        bpy.context.scene.cycles.adaptive_threshold = 0.10000000149011612
        bpy.context.scene.cycles.samples = 100
        bpy.context.scene.cycles.use_denoising = True
        bpy.context.scene.cycles.max_bounces = 8
        bpy.context.scene.cycles.diffuse_bounces = 2
        bpy.context.scene.cycles.glossy_bounces = 4
        bpy.context.scene.cycles.transmission_bounces = 8
        bpy.context.scene.cycles.volume_bounces = 2
        bpy.context.scene.cycles.transparent_max_bounces = 4
    elif sna_updated_prop == "High":
        bpy.context.scene.cycles.use_adaptive_sampling = True
        bpy.context.scene.cycles.adaptive_threshold = 0.05000000074505806
        bpy.context.scene.cycles.samples = 300
        bpy.context.scene.cycles.use_denoising = True
        bpy.context.scene.cycles.max_bounces = 12
        bpy.context.scene.cycles.diffuse_bounces = 4
        bpy.context.scene.cycles.glossy_bounces = 8
        bpy.context.scene.cycles.transmission_bounces = 12
        bpy.context.scene.cycles.volume_bounces = 2
        bpy.context.scene.cycles.transparent_max_bounces = 8
    elif sna_updated_prop == "Ultra":
        bpy.context.scene.cycles.use_adaptive_sampling = True
        bpy.context.scene.cycles.adaptive_threshold = 0.009999999776482582
        bpy.context.scene.cycles.samples = 1024
        bpy.context.scene.cycles.use_denoising = True
        bpy.context.scene.cycles.max_bounces = 32
        bpy.context.scene.cycles.diffuse_bounces = 8
        bpy.context.scene.cycles.glossy_bounces = 12
        bpy.context.scene.cycles.transmission_bounces = 24
        bpy.context.scene.cycles.volume_bounces = 8
        bpy.context.scene.cycles.transparent_max_bounces = 16
    else:
        pass


class SNA_MT_2D4D7(bpy.types.Menu):
    bl_idname = "SNA_MT_2D4D7"
    bl_label = "Extrude Utils"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('view3d.edit_mesh_extrude_move_shrink_fatten', text='Extrude Along Normals', icon_value=482, emboss=True, depress=False)
        op = layout.operator('mesh.extrude_faces_move', text='Extrude Individual Faces', icon_value=48, emboss=True, depress=False)
        op = layout.operator('view3d.edit_mesh_extrude_manifold_normal', text='Extrude Manifold', icon_value=357, emboss=True, depress=False)
        op = layout.operator('mesh.spin', text='Spin', icon_value=340, emboss=True, depress=False)


class SNA_MT_E31F3(bpy.types.Menu):
    bl_idname = "SNA_MT_E31F3"
    bl_label = "Delete Utils"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('mesh.delete', text='Verticles', icon_value=546, emboss=True, depress=False)
        op.type = 'VERT'
        op = layout.operator('mesh.delete', text='Edges', icon_value=547, emboss=False, depress=False)
        op.type = 'EDGE'
        op = layout.operator('mesh.delete', text='Faces', icon_value=548, emboss=True, depress=False)
        op.type = 'FACE'
        op = layout.operator('sna.open_dissolve_utils_pie_menu_69ceb', text='Dissolve', icon_value=478, emboss=True, depress=False)


class SNA_OT_Open_Dissolve_Utils_Pie_Menu_69Ceb(bpy.types.Operator):
    bl_idname = "sna.open_dissolve_utils_pie_menu_69ceb"
    bl_label = "Open Dissolve Utils Pie Menu"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_menu_pie(name="SNA_MT_DED90")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_MT_DED90(bpy.types.Menu):
    bl_idname = "SNA_MT_DED90"
    bl_label = "Dissolve Utils"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.menu_pie()
        op = layout.operator('mesh.dissolve_verts', text='Verticles', icon_value=546, emboss=True, depress=False)
        op = layout.operator('mesh.dissolve_edges', text='Edges', icon_value=547, emboss=True, depress=False)
        op = layout.operator('mesh.dissolve_faces', text='Faces', icon_value=548, emboss=True, depress=False)


class SNA_MT_3C28B(bpy.types.Menu):
    bl_idname = "SNA_MT_3C28B"
    bl_label = "Scale Utils"

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout.column_flow(columns=1)
        layout.operator_context = "INVOKE_DEFAULT"
        op = layout.operator('sna.apply_scale_to_all_operator_799b2', text='Apply Scale to All', icon_value=0, emboss=True, depress=False)


class SNA_OT_Apply_Scale_To_All_Operator_799B2(bpy.types.Operator):
    bl_idname = "sna.apply_scale_to_all_operator_799b2"
    bl_label = "Apply Scale to All Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', location=False, rotation=False, scale=True, properties=False, isolate_users=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_FRAME_UTILITIES_3C275(bpy.types.Panel):
    bl_label = 'Frame Utilities'
    bl_idname = 'SNA_PT_FRAME_UTILITIES_3C275'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'BUU!'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_ADDB3 = layout.box()
        box_ADDB3.alert = False
        box_ADDB3.enabled = True
        box_ADDB3.active = True
        box_ADDB3.use_property_split = False
        box_ADDB3.use_property_decorate = False
        box_ADDB3.alignment = 'Expand'.upper()
        box_ADDB3.scale_x = 1.0
        box_ADDB3.scale_y = 1.0
        if not True: box_ADDB3.operator_context = "EXEC_DEFAULT"
        box_ADDB3.label(text='Image Resolution', icon_value=183)
        col_9D963 = box_ADDB3.column(heading='', align=False)
        col_9D963.alert = False
        col_9D963.enabled = True
        col_9D963.active = True
        col_9D963.use_property_split = False
        col_9D963.use_property_decorate = False
        col_9D963.scale_x = 1.0
        col_9D963.scale_y = 1.0
        col_9D963.alignment = 'Expand'.upper()
        col_9D963.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_38F1B = col_9D963.row(heading='', align=False)
        row_38F1B.alert = False
        row_38F1B.enabled = True
        row_38F1B.active = True
        row_38F1B.use_property_split = False
        row_38F1B.use_property_decorate = False
        row_38F1B.scale_x = 1.0
        row_38F1B.scale_y = 1.149999976158142
        row_38F1B.alignment = 'Expand'.upper()
        row_38F1B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_38F1B.prop(bpy.context.scene, 'sna_resolution_', text=bpy.context.scene.sna_resolution_, icon_value=0, emboss=True, expand=True)
        row_4E58D = col_9D963.row(heading='', align=False)
        row_4E58D.alert = False
        row_4E58D.enabled = True
        row_4E58D.active = True
        row_4E58D.use_property_split = False
        row_4E58D.use_property_decorate = False
        row_4E58D.scale_x = 1.0
        row_4E58D.scale_y = 0.8999999761581421
        row_4E58D.alignment = 'Expand'.upper()
        row_4E58D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_4E58D.label(text='Resolution %', icon_value=0)
        row_4E58D.prop(bpy.context.scene.render, 'resolution_percentage', text='', icon_value=0, emboss=True)
        box_53AEB = layout.box()
        box_53AEB.alert = False
        box_53AEB.enabled = True
        box_53AEB.active = True
        box_53AEB.use_property_split = False
        box_53AEB.use_property_decorate = False
        box_53AEB.alignment = 'Expand'.upper()
        box_53AEB.scale_x = 1.0
        box_53AEB.scale_y = 1.0
        if not True: box_53AEB.operator_context = "EXEC_DEFAULT"
        box_53AEB.label(text='Image Dimensions', icon_value=75)
        row_5CDE6 = box_53AEB.row(heading='', align=False)
        row_5CDE6.alert = False
        row_5CDE6.enabled = True
        row_5CDE6.active = True
        row_5CDE6.use_property_split = False
        row_5CDE6.use_property_decorate = False
        row_5CDE6.scale_x = 1.0
        row_5CDE6.scale_y = 1.100000023841858
        row_5CDE6.alignment = 'Expand'.upper()
        row_5CDE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_4B93D = row_5CDE6.column(heading='', align=False)
        col_4B93D.alert = False
        col_4B93D.enabled = True
        col_4B93D.active = True
        col_4B93D.use_property_split = False
        col_4B93D.use_property_decorate = False
        col_4B93D.scale_x = 1.0
        col_4B93D.scale_y = 1.0
        col_4B93D.alignment = 'Expand'.upper()
        col_4B93D.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_4B93D.prop(bpy.context.scene, 'sna_image_dimensions', text=bpy.context.scene.sna_image_dimensions, icon_value=0, emboss=True, expand=True)
        col_74AA4 = row_5CDE6.column(heading='', align=False)
        col_74AA4.alert = False
        col_74AA4.enabled = True
        col_74AA4.active = True
        col_74AA4.use_property_split = False
        col_74AA4.use_property_decorate = False
        col_74AA4.scale_x = 1.0
        col_74AA4.scale_y = 1.0
        col_74AA4.alignment = 'Expand'.upper()
        col_74AA4.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_74AA4.label(text='1920x1080', icon_value=17)
        col_74AA4.label(text='1080x1080', icon_value=17)
        col_74AA4.label(text='2560x1080', icon_value=17)
        col_74AA4.label(text='768x1024', icon_value=17)
        col_74AA4.label(text='1080x1350', icon_value=17)
        box_4CD04 = box_53AEB.box()
        box_4CD04.alert = False
        box_4CD04.enabled = True
        box_4CD04.active = True
        box_4CD04.use_property_split = False
        box_4CD04.use_property_decorate = False
        box_4CD04.alignment = 'Expand'.upper()
        box_4CD04.scale_x = 1.0
        box_4CD04.scale_y = 1.0
        if not True: box_4CD04.operator_context = "EXEC_DEFAULT"
        box_4CD04.label(text='Current Dimensions', icon_value=385)
        col_F8C95 = box_4CD04.column(heading='', align=False)
        col_F8C95.alert = False
        col_F8C95.enabled = True
        col_F8C95.active = True
        col_F8C95.use_property_split = True
        col_F8C95.use_property_decorate = False
        col_F8C95.scale_x = 1.0
        col_F8C95.scale_y = 1.0
        col_F8C95.alignment = 'Expand'.upper()
        col_F8C95.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_F8C95.prop(bpy.context.scene.render, 'resolution_x', text='Resolution X', icon_value=0, emboss=True)
        col_F8C95.prop(bpy.context.scene.render, 'resolution_y', text='Resolution Y', icon_value=0, emboss=True)
        row_081EE = box_53AEB.row(heading='', align=False)
        row_081EE.alert = False
        row_081EE.enabled = True
        row_081EE.active = True
        row_081EE.use_property_split = False
        row_081EE.use_property_decorate = False
        row_081EE.scale_x = 1.0
        row_081EE.scale_y = 1.149999976158142
        row_081EE.alignment = 'Expand'.upper()
        row_081EE.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_081EE.operator('sna.flip_operator_d4930', text='Flip', icon_value=692, emboss=True, depress=False)


class SNA_OT_Flip_Operator_D4930(bpy.types.Operator):
    bl_idname = "sna.flip_operator_d4930"
    bl_label = "Flip Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_temp_resolution_x = bpy.context.scene.render.resolution_x
        bpy.context.scene.render.resolution_x = bpy.context.scene.render.resolution_y
        bpy.context.scene.render.resolution_y = bpy.context.scene.sna_temp_resolution_x
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_RENDER_UTILITIES_46FEA(bpy.types.Panel):
    bl_label = 'Render Utilities'
    bl_idname = 'SNA_PT_RENDER_UTILITIES_46FEA'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'BUU!'
    bl_order = 0
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene.render, 'engine', text='Render Engine', icon_value=0, emboss=True, expand=True)
        layout.separator(factor=1.0)
        row_23388 = layout.row(heading='', align=False)
        row_23388.alert = False
        row_23388.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        row_23388.active = True
        row_23388.use_property_split = True
        row_23388.use_property_decorate = False
        row_23388.scale_x = 1.0
        row_23388.scale_y = 1.0
        row_23388.alignment = 'Expand'.upper()
        row_23388.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_23388.prop(bpy.data.scenes['Scene'].cycles, 'device', text='Device', icon_value=0, emboss=True, expand=False, slider=False)
        box_AED0E = layout.box()
        box_AED0E.alert = False
        box_AED0E.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        box_AED0E.active = True
        box_AED0E.use_property_split = False
        box_AED0E.use_property_decorate = False
        box_AED0E.alignment = 'Expand'.upper()
        box_AED0E.scale_x = 1.0
        box_AED0E.scale_y = 1.0
        if not True: box_AED0E.operator_context = "EXEC_DEFAULT"
        box_AED0E.label(text='Set Render Quality', icon_value=0)
        row_A60BA = box_AED0E.row(heading='', align=False)
        row_A60BA.alert = False
        row_A60BA.enabled = True
        row_A60BA.active = True
        row_A60BA.use_property_split = False
        row_A60BA.use_property_decorate = False
        row_A60BA.scale_x = 1.0
        row_A60BA.scale_y = 1.149999976158142
        row_A60BA.alignment = 'Expand'.upper()
        row_A60BA.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_A60BA.prop(bpy.context.scene, 'sna_render_quality', text=bpy.context.scene.sna_render_quality, icon_value=0, emboss=True, expand=True)
        layout.separator(factor=1.0)
        row_7CBA9 = layout.row(heading='', align=False)
        row_7CBA9.alert = False
        row_7CBA9.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        row_7CBA9.active = True
        row_7CBA9.use_property_split = False
        row_7CBA9.use_property_decorate = False
        row_7CBA9.scale_x = 1.0
        row_7CBA9.scale_y = 1.0
        row_7CBA9.alignment = 'Expand'.upper()
        row_7CBA9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_7CBA9.label(text='Current Render Settings', icon_value=0)
        box_3251D = layout.box()
        box_3251D.alert = False
        box_3251D.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        box_3251D.active = True
        box_3251D.use_property_split = True
        box_3251D.use_property_decorate = False
        box_3251D.alignment = 'Expand'.upper()
        box_3251D.scale_x = 1.0
        box_3251D.scale_y = 1.0
        if not True: box_3251D.operator_context = "EXEC_DEFAULT"
        row_03470 = box_3251D.row(heading='', align=False)
        row_03470.alert = False
        row_03470.enabled = True
        row_03470.active = True
        row_03470.use_property_split = False
        row_03470.use_property_decorate = False
        row_03470.scale_x = 1.0
        row_03470.scale_y = 1.0
        row_03470.alignment = 'Expand'.upper()
        row_03470.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_03470.label(text='Noise Thershold', icon_value=0)
        row_03470.prop(bpy.data.scenes['Scene'].cycles, 'use_adaptive_sampling', text='', icon_value=0, emboss=True, expand=True)
        row_03470.prop(bpy.data.scenes['Scene'].cycles, 'adaptive_threshold', text='', icon_value=0, emboss=True, expand=True)
        box_3251D.prop(bpy.context.scene.cycles, 'samples', text='Max Samples', icon_value=0, emboss=True, expand=True)
        box_5CDE3 = layout.box()
        box_5CDE3.alert = False
        box_5CDE3.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        box_5CDE3.active = True
        box_5CDE3.use_property_split = True
        box_5CDE3.use_property_decorate = False
        box_5CDE3.alignment = 'Expand'.upper()
        box_5CDE3.scale_x = 1.0
        box_5CDE3.scale_y = 1.0
        if not True: box_5CDE3.operator_context = "EXEC_DEFAULT"
        box_5CDE3.prop(bpy.context.scene.cycles, 'use_denoising', text='Denoise', icon_value=0, emboss=True, expand=True)
        box_CD5FC = layout.box()
        box_CD5FC.alert = False
        box_CD5FC.enabled = (bpy.context.scene.render.engine == 'CYCLES')
        box_CD5FC.active = True
        box_CD5FC.use_property_split = False
        box_CD5FC.use_property_decorate = False
        box_CD5FC.alignment = 'Expand'.upper()
        box_CD5FC.scale_x = 1.0
        box_CD5FC.scale_y = 1.0
        if not True: box_CD5FC.operator_context = "EXEC_DEFAULT"
        col_908E3 = box_CD5FC.column(heading='', align=False)
        col_908E3.alert = False
        col_908E3.enabled = True
        col_908E3.active = True
        col_908E3.use_property_split = True
        col_908E3.use_property_decorate = False
        col_908E3.scale_x = 1.0299999713897705
        col_908E3.scale_y = 1.0
        col_908E3.alignment = 'Expand'.upper()
        col_908E3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_908E3.prop(bpy.context.scene.cycles, 'max_bounces', text='Total', icon_value=0, emboss=True, expand=True)
        col_908E3.separator(factor=0.5)
        col_F5EFB = col_908E3.column(heading='', align=True)
        col_F5EFB.alert = False
        col_F5EFB.enabled = True
        col_F5EFB.active = True
        col_F5EFB.use_property_split = True
        col_F5EFB.use_property_decorate = False
        col_F5EFB.scale_x = 1.0299999713897705
        col_F5EFB.scale_y = 1.0
        col_F5EFB.alignment = 'Expand'.upper()
        col_F5EFB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_F5EFB.prop(bpy.context.scene.cycles, 'diffuse_bounces', text='Diffuse', icon_value=0, emboss=True, expand=True)
        col_F5EFB.prop(bpy.context.scene.cycles, 'glossy_bounces', text='Glossy', icon_value=0, emboss=True, expand=True)
        col_F5EFB.prop(bpy.context.scene.cycles, 'transmission_bounces', text='Transmission', icon_value=0, emboss=True, expand=True)
        col_F5EFB.prop(bpy.context.scene.cycles, 'volume_bounces', text='Volume', icon_value=0, emboss=True, expand=True)
        col_908E3.separator(factor=0.5)
        col_908E3.prop(bpy.context.scene.cycles, 'transparent_max_bounces', text='Transparent', icon_value=0, emboss=True, expand=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_resolution_ = bpy.props.EnumProperty(name='Resolution %', description='', items=[('0.25x', '0.25x', '', 0, 0), ('0.5x', '0.5x', '', 0, 1), ('1x', '1x', '', 0, 2), ('1.5x', '1.5x', '', 0, 3), ('2x', '2x', '', 0, 4), ('3x', '3x', '', 0, 5)], update=sna_update_sna_resolution__88E21)
    bpy.types.Scene.sna_image_dimensions = bpy.props.EnumProperty(name='Image Dimensions', description='', items=[('Default 16:9', 'Default 16:9', '', 0, 0), ('Square 1:1', 'Square 1:1', '', 0, 1), ('Filmic 21:9', 'Filmic 21:9', '', 0, 2), ('Instagram 3:4', 'Instagram 3:4', '', 0, 3), ('Facebook 4:5', 'Facebook 4:5', '', 0, 4)], update=sna_update_sna_image_dimensions_B129B)
    bpy.types.Scene.sna_temp_resolution_x = bpy.props.IntProperty(name='Temp Resolution X', description='', default=0, subtype='NONE')
    bpy.types.Scene.sna_render_quality = bpy.props.EnumProperty(name='Render Quality', description='', items=[('Mini', 'Mini', '', 0, 0), ('Low', 'Low', '', 0, 1), ('Normal', 'Normal', '', 0, 2), ('High', 'High', '', 0, 3), ('Ultra', 'Ultra', '', 0, 4)], update=sna_update_sna_render_quality_9B4C8)
    bpy.utils.register_class(SNA_MT_2D4D7)
    bpy.utils.register_class(SNA_MT_E31F3)
    bpy.utils.register_class(SNA_OT_Open_Dissolve_Utils_Pie_Menu_69Ceb)
    bpy.utils.register_class(SNA_MT_DED90)
    bpy.utils.register_class(SNA_MT_3C28B)
    bpy.utils.register_class(SNA_OT_Apply_Scale_To_All_Operator_799B2)
    bpy.utils.register_class(SNA_PT_FRAME_UTILITIES_3C275)
    bpy.utils.register_class(SNA_OT_Flip_Operator_D4930)
    bpy.utils.register_class(SNA_PT_RENDER_UTILITIES_46FEA)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'E', 'PRESS',
        ctrl=False, alt=True, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_2D4D7'
    addon_keymaps['C4296'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu_pie', 'X', 'PRESS',
        ctrl=False, alt=True, shift=False, repeat=False)
    kmi.properties.name = 'SNA_MT_E31F3'
    addon_keymaps['0793A'] = (km, kmi)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new('wm.call_menu', 'A', 'PRESS',
        ctrl=True, alt=False, shift=True, repeat=False)
    kmi.properties.name = 'SNA_MT_3C28B'
    addon_keymaps['0019F'] = (km, kmi)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_render_quality
    del bpy.types.Scene.sna_temp_resolution_x
    del bpy.types.Scene.sna_image_dimensions
    del bpy.types.Scene.sna_resolution_
    bpy.utils.unregister_class(SNA_MT_2D4D7)
    bpy.utils.unregister_class(SNA_MT_E31F3)
    bpy.utils.unregister_class(SNA_OT_Open_Dissolve_Utils_Pie_Menu_69Ceb)
    bpy.utils.unregister_class(SNA_MT_DED90)
    bpy.utils.unregister_class(SNA_MT_3C28B)
    bpy.utils.unregister_class(SNA_OT_Apply_Scale_To_All_Operator_799B2)
    bpy.utils.unregister_class(SNA_PT_FRAME_UTILITIES_3C275)
    bpy.utils.unregister_class(SNA_OT_Flip_Operator_D4930)
    bpy.utils.unregister_class(SNA_PT_RENDER_UTILITIES_46FEA)
